//! DNS-over-HTTPS (DoH) resolution via hickory-resolver

use hickory_resolver::config::{LookupIpStrategy, NameServerConfig, ResolveHosts, ResolverConfig};
use hickory_resolver::net::runtime::TokioRuntimeProvider;
use hickory_resolver::TokioResolver;

use std::net::IpAddr;
use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;

use tokio::sync::OnceCell;

use super::gai::GaiResolver;
use super::{Addrs, Name, Resolve, Resolving, SocketAddrs};
use crate::error::BoxError;

/// A DNS-over-HTTPS resolver backed by hickory-resolver.
pub struct DohResolver {
    state: Arc<OnceCell<Arc<TokioResolver>>>,
    bootstrap: Arc<dyn Resolve>,
    doh_host: String,
    doh_path: String,
    doh_port: u16,
}

impl std::fmt::Debug for DohResolver {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DohResolver")
            .field("doh_host", &self.doh_host)
            .field("doh_path", &self.doh_path)
            .field("doh_port", &self.doh_port)
            .finish()
    }
}

impl Clone for DohResolver {
    fn clone(&self) -> Self {
        Self {
            state: self.state.clone(),
            bootstrap: self.bootstrap.clone(),
            doh_host: self.doh_host.clone(),
            doh_path: self.doh_path.clone(),
            doh_port: self.doh_port,
        }
    }
}

impl DohResolver {
    /// Create a new DoH resolver from a URL like `https://cloudflare-dns.com/dns-query`.
    ///
    /// The host is resolved via the system resolver (GaiResolver) on first lookup.
    pub fn new(url: &str) -> Result<Self, BoxError> {
        let parsed = url::Url::parse(url)?;
        // DoH is HTTPS-only: an `http://` URL would otherwise be silently
        // tunnelled through TLS to port 443; reject at construction.
        if parsed.scheme() != "https" {
            return Err("DoH URL must use the \"https\" scheme".into());
        }
        let host = parsed
            .host_str()
            .ok_or("DoH URL must have a host")?
            .to_string();
        // Strip IPv6 brackets; url::host_str() includes them
        let host = host
            .trim_start_matches('[')
            .trim_end_matches(']')
            .to_string();
        let port = parsed.port().unwrap_or(443);
        let mut path = parsed.path().to_string();
        // Preserve custom query strings (e.g. `?dataset=...`); skip empty
        // queries (`https://host/path?`) to avoid a trailing `?`.
        if let Some(query) = parsed.query() {
            if !query.is_empty() {
                path.push('?');
                path.push_str(query);
            }
        }
        let bootstrap: Arc<dyn Resolve> = Arc::new(GaiResolver::new());
        Ok(Self {
            state: Arc::new(OnceCell::new()),
            bootstrap,
            doh_host: host,
            doh_path: path,
            doh_port: port,
        })
    }

    async fn get_resolver(&self) -> Result<Arc<TokioResolver>, BoxError> {
        self.state
            .get_or_try_init(|| async {
                let addrs = self
                    .bootstrap
                    .resolve(Name::from_str(&self.doh_host)?)
                    .await?;
                let ips: Vec<IpAddr> = addrs.map(|a| a.ip()).collect();

                let name_servers: Vec<NameServerConfig> = ips
                    .iter()
                    .map(|&ip| {
                        let mut ns = NameServerConfig::https(
                            ip,
                            self.doh_host.clone().into(),
                            Some(self.doh_path.clone().into()),
                        );
                        // The `https` constructor hardcodes port 443 in the
                        // connection config; honor the configured custom DoH
                        // port so non-default ports work.
                        for conn in ns.connections.iter_mut() {
                            conn.port = self.doh_port;
                        }
                        ns
                    })
                    .collect();
                let config = ResolverConfig::from_parts(None, vec![], name_servers);

                let mut builder =
                    TokioResolver::builder_with_config(config, TokioRuntimeProvider::default());
                let opts = builder.options_mut();
                opts.timeout = Duration::from_secs(5);
                opts.ip_strategy = LookupIpStrategy::Ipv4AndIpv6;
                opts.use_hosts_file = ResolveHosts::Never;
                let resolver = Arc::new(builder.build()?);
                Ok::<_, BoxError>(resolver)
            })
            .await
            .map(Arc::clone)
    }
}

impl Resolve for DohResolver {
    fn resolve(&self, name: Name) -> Resolving {
        let this = self.clone();
        Box::pin(async move {
            let resolver = this.get_resolver().await?;
            // `opts.timeout` (5s, set in `get_resolver`) bounds the lookup;
            // the cache layer additionally enforces its own
            // `DNS_RESOLUTION_TIMEOUT`. The previously redundant outer
            // `timeout` has been removed to avoid a stacked ~15s worst case.
            let lookup = resolver
                .lookup_ip(name.as_str())
                .await
                .map_err(BoxError::from)?;
            let ips: Vec<IpAddr> = lookup.iter().collect();
            let addrs: Addrs = Box::new(SocketAddrs {
                iter: ips.into_iter(),
            });
            Ok(addrs)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Client;

    #[test]
    fn new_cloudflare() {
        let resolver = DohResolver::new("https://cloudflare-dns.com/dns-query").unwrap();
        assert_eq!(resolver.doh_host, "cloudflare-dns.com");
        assert_eq!(resolver.doh_port, 443);
        assert_eq!(resolver.doh_path, "/dns-query");
    }

    #[test]
    fn new_custom_port() {
        let resolver = DohResolver::new("https://dns.google:8443/dns-query").unwrap();
        assert_eq!(resolver.doh_host, "dns.google");
        assert_eq!(resolver.doh_port, 8443);
        assert_eq!(resolver.doh_path, "/dns-query");
    }

    #[test]
    fn new_preserves_query_string() {
        let resolver = DohResolver::new("https://example.com/dns-query?dataset=test").unwrap();
        assert_eq!(resolver.doh_path, "/dns-query?dataset=test");
    }

    #[test]
    fn new_ignores_empty_query_string() {
        let resolver = DohResolver::new("https://example.com/dns-query?").unwrap();
        assert_eq!(resolver.doh_path, "/dns-query");
    }

    #[test]
    fn new_ipv6_literal() {
        let resolver = DohResolver::new("https://[2606:4700:4700::1111]/dns-query").unwrap();
        assert_eq!(resolver.doh_host, "2606:4700:4700::1111");
        assert_eq!(resolver.doh_port, 443);
        assert_eq!(resolver.doh_path, "/dns-query");
    }

    #[test]
    fn new_rejects_invalid_url() {
        let err = DohResolver::new("not a url").unwrap_err();
        assert!(err.to_string().contains("relative URL"), "{err}");
    }

    #[test]
    fn new_rejects_non_https_scheme() {
        for url in [
            "http://cloudflare-dns.com/dns-query",
            "http://dns.google/resolve",
            "tcp://1.1.1.1/dns-query",
            "ftp://example.com/dns-query",
        ] {
            let err = DohResolver::new(url).unwrap_err();
            assert!(
                err.to_string().contains("https"),
                "expected non-https rejection for {url:?}, got {err}"
            );
        }
        // The canonical form still works and defaults the TLS port.
        let ok = DohResolver::new("https://cloudflare-dns.com/dns-query").unwrap();
        assert_eq!(ok.doh_port, 443);
    }

    #[test]
    fn builder_creates_with_doh_resolver() {
        let resolver = DohResolver::new("https://cloudflare-dns.com/dns-query").unwrap();
        let client = Client::builder().dns_resolver(resolver).build();
        assert!(client.is_ok());
    }

    #[test]
    fn builder_creates_with_dot_resolver() {
        use crate::dns::dot::DotResolver;
        let resolver = DotResolver::new("1.1.1.1");
        let client = Client::builder().dns_resolver(resolver).build();
        assert!(client.is_ok());
    }

    #[test]
    fn builder_creates_with_multi_resolver() {
        let r1: Arc<dyn Resolve> =
            Arc::new(DohResolver::new("https://cloudflare-dns.com/dns-query").unwrap());
        let r2: Arc<dyn Resolve> = Arc::new(crate::dns::gai::GaiResolver::new());
        let client = Client::builder().dns_resolver(vec![r1, r2]).build();
        assert!(client.is_ok());
    }

    #[test]
    fn debug_output() {
        let resolver = DohResolver::new("https://cloudflare-dns.com:8443/custom-path").unwrap();
        let debug = format!("{:?}", resolver);
        assert!(debug.contains("cloudflare-dns.com"), "{debug}");
        assert!(debug.contains("/custom-path"), "{debug}");
        assert!(debug.contains("8443"), "{debug}");
    }
}
