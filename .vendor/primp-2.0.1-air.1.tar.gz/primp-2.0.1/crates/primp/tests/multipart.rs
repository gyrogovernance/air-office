mod support;
use http_body_util::BodyExt;
use support::server;

#[tokio::test]
async fn text_part() {
    let _ = env_logger::try_init();

    let form = primp::multipart::Form::new().text("foo", "bar");

    let expected_body = format!(
        "\
         --{0}\r\n\
         Content-Disposition: form-data; name=\"foo\"\r\n\r\n\
         bar\r\n\
         --{0}--\r\n\
         ",
        form.boundary()
    );

    let ct = format!("multipart/form-data; boundary={}", form.boundary());

    let server = server::http(move |mut req| {
        let ct = ct.clone();
        let expected_body = expected_body.clone();
        async move {
            assert_eq!(req.method(), "POST");
            assert_eq!(req.headers()["content-type"], ct);
            assert_eq!(
                req.headers()["content-length"],
                expected_body.len().to_string()
            );

            let mut full: Vec<u8> = Vec::new();
            while let Some(item) = req.body_mut().frame().await {
                full.extend(&*item.unwrap().into_data().unwrap());
            }

            assert_eq!(full, expected_body.as_bytes());

            http::Response::default()
        }
    });

    let url = format!("http://{}/multipart/1", server.addr());

    let res = primp::Client::new()
        .post(&url)
        .multipart(form)
        .send()
        .await
        .unwrap();

    assert_eq!(res.url().as_str(), &url);
    assert_eq!(res.status(), primp::StatusCode::OK);
}

#[cfg(feature = "stream")]
#[tokio::test]
async fn stream_part() {
    use futures_util::stream;
    use std::future;

    let _ = env_logger::try_init();

    let stream = primp::Body::wrap_stream(stream::once(future::ready(Ok::<_, primp::Error>(
        "part1 part2".to_owned(),
    ))));
    let part = primp::multipart::Part::stream(stream);

    let form = primp::multipart::Form::new()
        .text("foo", "bar")
        .part("part_stream", part);

    let expected_body = format!(
        "\
         --{0}\r\n\
         Content-Disposition: form-data; name=\"foo\"\r\n\
         \r\n\
         bar\r\n\
         --{0}\r\n\
         Content-Disposition: form-data; name=\"part_stream\"\r\n\
         \r\n\
         part1 part2\r\n\
         --{0}--\r\n\
         ",
        form.boundary()
    );

    let ct = format!("multipart/form-data; boundary={}", form.boundary());

    let server = server::http(move |req| {
        let ct = ct.clone();
        let expected_body = expected_body.clone();
        async move {
            assert_eq!(req.method(), "POST");
            assert_eq!(req.headers()["content-type"], ct);
            assert_eq!(req.headers()["transfer-encoding"], "chunked");

            let full = req.collect().await.unwrap().to_bytes();

            assert_eq!(full, expected_body.as_bytes());

            http::Response::default()
        }
    });

    let url = format!("http://{}/multipart/1", server.addr());

    let client = primp::Client::new();

    let res = client
        .post(&url)
        .multipart(form)
        .send()
        .await
        .expect("Failed to post multipart");
    assert_eq!(res.url().as_str(), &url);
    assert_eq!(res.status(), primp::StatusCode::OK);
}

#[tokio::test]
async fn multipart_does_not_clobber_pre_set_content_type() {
    let _ = env_logger::try_init();

    let form = primp::multipart::Form::new().text("foo", "bar");

    let server = server::http(move |req| async move {
        let cts: Vec<String> = req
            .headers()
            .get_all("content-type")
            .iter()
            .filter_map(|v| v.to_str().ok())
            .map(|s| s.to_string())
            .collect();
        http::Response::new(primp::Body::from(cts.join(" | ")))
    });

    let url = format!("http://{}/multipart/4", server.addr());

    let res = primp::Client::new()
        .post(&url)
        .header("content-type", "application/x-custom")
        .multipart(form)
        .send()
        .await
        .unwrap();

    assert_eq!(res.status(), primp::StatusCode::OK);
    let body = res.text().await.unwrap();
    assert_eq!(
        body, "application/x-custom",
        "multipart() must not append a second content-type header"
    );
}

#[cfg(feature = "stream")]
#[tokio::test]
async fn async_impl_file_part() {
    let _ = env_logger::try_init();

    let form = primp::multipart::Form::new()
        .file("foo", "Cargo.toml")
        .await
        .unwrap();

    let fcontents = std::fs::read_to_string("Cargo.toml").unwrap();
    let mime = mime_guess::from_ext("toml")
        .first_or_octet_stream()
        .to_string();

    let expected_body = format!(
        "\
         --{0}\r\n\
         Content-Disposition: form-data; name=\"foo\"; filename=\"Cargo.toml\"\r\n\
         Content-Type: {2}\r\n\r\n\
         {1}\r\n\
         --{0}--\r\n\
         ",
        form.boundary(),
        fcontents,
        mime
    );

    let ct = format!("multipart/form-data; boundary={}", form.boundary());

    let server = server::http(move |req| {
        let ct = ct.clone();
        let expected_body = expected_body.clone();
        async move {
            assert_eq!(req.method(), "POST");
            assert_eq!(req.headers()["content-type"], ct);
            // files know their exact size
            assert_eq!(
                req.headers()["content-length"],
                expected_body.len().to_string()
            );
            let full = req.collect().await.unwrap().to_bytes();

            assert_eq!(full, expected_body.as_bytes());

            http::Response::default()
        }
    });

    let url = format!("http://{}/multipart/3", server.addr());

    let res = primp::Client::new()
        .post(&url)
        .multipart(form)
        .send()
        .await
        .unwrap();

    assert_eq!(res.url().as_str(), &url);
    assert_eq!(res.status(), primp::StatusCode::OK);
}
